# Dependencies
node_modules/
.expo/
.expo-shared/

# Config files with secrets
src/config/firebase.js

# macOS
.DS_Store

# Environment
.env
.env.local

# IDE
.vscode/
.idea/
*.swp
*.swo

# Build artifacts
dist/
*.log
npm-debug.log*
yarn-debug.log*
yarn-error.log*

# iOS
*.ipa
*.dSYM.zip
*.dSYM
ios/Pods/
ios/build/

# Android
*.apk
*.aab
android/app/build/
android/build/

# Testing
coverage/
