import React from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  ScrollView,
} from 'react-native';
import { useRoute } from '@react-navigation/native';
import { theme } from '../config/theme';

const PaymentSummaryScreen = ({ navigation }) => {
  const route = useRoute();
  const { duration, cost, vehicleType } = route.params;

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    if (hours > 0) {
      return `${hours}h ${minutes}m`;
    }
    return `${minutes}m`;
  };

  const handlePayment = (method) => {
    navigation.navigate('PaymentConfirmation', { method, amount: cost });
  };

  return (
    <ScrollView style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.successIcon}>✓</Text>
        <Text style={styles.headerTitle}>Ride Completed!</Text>
        <Text style={styles.headerSubtitle}>Thank you for riding with RideON</Text>
      </View>

      <View style={styles.summaryCard}>
        <Text style={styles.sectionTitle}>Ride Summary</Text>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Vehicle Type</Text>
          <Text style={styles.summaryValue}>
            {vehicleType === 'cycle' ? 'Cycle' : 'E-Scooter'}
          </Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Duration</Text>
          <Text style={styles.summaryValue}>{formatDuration(duration)}</Text>
        </View>

        <View style={styles.summaryRow}>
          <Text style={styles.summaryLabel}>Base Fare</Text>
          <Text style={styles.summaryValue}>₹{cost}</Text>
        </View>

        <View style={styles.divider} />

        <View style={styles.totalRow}>
          <Text style={styles.totalLabel}>Total Amount</Text>
          <Text style={styles.totalValue}>₹{cost}</Text>
        </View>
      </View>

      <View style={styles.paymentCard}>
        <Text style={styles.sectionTitle}>Select Payment Method</Text>

        <TouchableOpacity
          style={styles.paymentOption}
          onPress={() => handlePayment('UPI')}
        >
          <View style={styles.paymentIcon}>
            <Text style={styles.paymentIconText}>💳</Text>
          </View>
          <View style={styles.paymentInfo}>
            <Text style={styles.paymentTitle}>UPI Payment</Text>
            <Text style={styles.paymentDescription}>Pay via UPI apps</Text>
          </View>
          <Text style={styles.arrow}>→</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.paymentOption}
          onPress={() => handlePayment('Card')}
        >
          <View style={styles.paymentIcon}>
            <Text style={styles.paymentIconText}>💳</Text>
          </View>
          <View style={styles.paymentInfo}>
            <Text style={styles.paymentTitle}>Credit/Debit Card</Text>
            <Text style={styles.paymentDescription}>Pay using your card</Text>
          </View>
          <Text style={styles.arrow}>→</Text>
        </TouchableOpacity>

        <TouchableOpacity
          style={styles.paymentOption}
          onPress={() => handlePayment('Wallet')}
        >
          <View style={styles.paymentIcon}>
            <Text style={styles.paymentIconText}>👛</Text>
          </View>
          <View style={styles.paymentInfo}>
            <Text style={styles.paymentTitle}>RideON Wallet</Text>
            <Text style={styles.paymentDescription}>Pay from wallet balance</Text>
          </View>
          <Text style={styles.arrow}>→</Text>
        </TouchableOpacity>
      </View>
    </ScrollView>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    backgroundColor: theme.colors.secondary,
    padding: theme.spacing.xl,
    alignItems: 'center',
  },
  successIcon: {
    fontSize: 60,
    color: '#ffffff',
    marginBottom: theme.spacing.md,
  },
  headerTitle: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: '#ffffff',
    marginBottom: theme.spacing.xs,
  },
  headerSubtitle: {
    fontSize: theme.fontSize.sm,
    color: '#ffffff',
    opacity: 0.9,
  },
  summaryCard: {
    backgroundColor: theme.colors.card,
    margin: theme.spacing.md,
    padding: theme.spacing.lg,
    borderRadius: theme.borderRadius.lg,
    ...theme.shadows.medium,
  },
  sectionTitle: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginBottom: theme.spacing.md,
  },
  summaryRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    marginBottom: theme.spacing.md,
  },
  summaryLabel: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
  summaryValue: {
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.medium,
    color: theme.colors.text,
  },
  divider: {
    height: 1,
    backgroundColor: theme.colors.border,
    marginVertical: theme.spacing.md,
  },
  totalRow: {
    flexDirection: 'row',
    justifyContent: 'space-between',
  },
  totalLabel: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
  },
  totalValue: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  paymentCard: {
    backgroundColor: theme.colors.card,
    margin: theme.spacing.md,
    padding: theme.spacing.lg,
    borderRadius: theme.borderRadius.lg,
    ...theme.shadows.medium,
  },
  paymentOption: {
    flexDirection: 'row',
    alignItems: 'center',
    padding: theme.spacing.md,
    backgroundColor: theme.colors.background,
    borderRadius: theme.borderRadius.sm,
    marginBottom: theme.spacing.md,
  },
  paymentIcon: {
    width: 50,
    height: 50,
    borderRadius: 25,
    backgroundColor: theme.colors.card,
    justifyContent: 'center',
    alignItems: 'center',
    marginRight: theme.spacing.md,
  },
  paymentIconText: {
    fontSize: 24,
  },
  paymentInfo: {
    flex: 1,
  },
  paymentTitle: {
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  paymentDescription: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
  },
  arrow: {
    fontSize: 20,
    color: theme.colors.textSecondary,
  },
});

export default PaymentSummaryScreen;
