# Firebase Setup Guide for RideON

This guide will help you set up Firebase for the RideON mobile application.

## Step 1: Create Firebase Project

1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project"
3. Enter project name: `rideon-app` (or your preferred name)
4. Disable Google Analytics (optional)
5. Click "Create project"

## Step 2: Register Your App

### For Web/Expo
1. Click the web icon (</>)
2. Register app with nickname: "RideON Mobile"
3. Copy the Firebase configuration object
4. Click "Continue to console"

## Step 3: Enable Authentication

1. In Firebase Console, click "Authentication" from left sidebar
2. Click "Get started"
3. Click on "Sign-in method" tab
4. Click "Email/Password"
5. Toggle "Enable"
6. Click "Save"

## Step 4: Create Firestore Database

1. Click "Firestore Database" from left sidebar
2. Click "Create database"
3. Select "Start in production mode"
4. Choose a location closest to your users
5. Click "Enable"

## Step 5: Set Up Firestore Collections

### Create Collections

Click "Start collection" and create these collections:

#### 1. Users Collection
- Collection ID: `users`
- Document ID: Auto-ID (will be userId from Auth)
- Fields:
  - `name` (string)
  - `email` (string)
  - `phone` (string)
  - `collegeId` (string) - optional
  - `activeRide` (boolean) - default: false
  - `subscriptionStatus` (string) - default: "none"
  - `createdAt` (timestamp)

#### 2. Vehicles Collection
- Collection ID: `vehicles`
- Document ID: Auto-ID
- Fields:
  - `type` (string) - "cycle" or "escooter"
  - `status` (string) - "available" or "in-use"
  - `location` (map)
    - `latitude` (number)
    - `longitude` (number)
  - `batteryLevel` (number) - for e-scooters
  - `pricePerHour` (number)
  - `createdAt` (timestamp)

#### 3. Rides Collection
- Collection ID: `rides`
- Document ID: Auto-ID
- Fields:
  - `userId` (string)
  - `vehicleId` (string)
  - `startTime` (timestamp)
  - `endTime` (timestamp)
  - `totalCost` (number)
  - `status` (string) - "active" or "completed"

## Step 6: Configure Security Rules

1. Click on "Rules" tab in Firestore
2. Replace with these rules:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {

    // Users collection - users can only read/write their own data
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
      allow read: if request.auth != null; // Allow reading for admin purposes
    }

    // Vehicles collection - all authenticated users can read, only admins can write
    match /vehicles/{vehicleId} {
      allow read: if request.auth != null;
      allow create, update, delete: if request.auth != null;
      // TODO: Add admin role check for write operations in production
    }

    // Rides collection - users can only access their own rides
    match /rides/{rideId} {
      allow read: if request.auth != null;
      allow create: if request.auth != null;
      allow update: if request.auth != null &&
        (resource.data.userId == request.auth.uid ||
         !exists(/databases/$(database)/documents/rides/$(rideId)));
    }
  }
}
```

3. Click "Publish"

## Step 7: Add Sample Data

### Add Sample Vehicles

Go to Firestore Database and manually add some sample vehicles:

**Sample Cycle:**
```json
{
  "type": "cycle",
  "status": "available",
  "location": {
    "latitude": 28.6139,
    "longitude": 77.2090
  },
  "pricePerHour": 20,
  "createdAt": "2024-01-01T00:00:00Z"
}
```

**Sample E-Scooter:**
```json
{
  "type": "escooter",
  "status": "available",
  "location": {
    "latitude": 28.6129,
    "longitude": 77.2095
  },
  "batteryLevel": 85,
  "pricePerHour": 30,
  "createdAt": "2024-01-01T00:00:00Z"
}
```

## Step 8: Update App Configuration

1. Open `src/config/firebase.js` in your project
2. Replace the configuration with your Firebase config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY_HERE",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.appspot.com",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

3. Get your config values from:
   - Firebase Console → Project Settings (gear icon)
   - Scroll to "Your apps" section
   - Copy the config object

## Step 9: Test Configuration

1. Run your app: `npm start`
2. Try to sign up with a test email
3. Check Firebase Console → Authentication to see if user was created
4. Check Firestore to see if user document was created

## Step 10: Enable Firestore Indexes (if needed)

If you get index errors while querying:

1. Click on "Indexes" tab in Firestore
2. Firebase will show error messages with links to create indexes
3. Click the links to auto-create required indexes

Or manually create:

**Index for Active Rides:**
- Collection: `rides`
- Fields:
  - `userId` (Ascending)
  - `status` (Ascending)

**Index for User Rides:**
- Collection: `rides`
- Fields:
  - `userId` (Ascending)
  - `startTime` (Descending)

## Optional: Storage Setup (for future features)

1. Click "Storage" from left sidebar
2. Click "Get started"
3. Use default security rules
4. Click "Done"

## Optional: Enable Firebase Analytics

1. Click "Analytics" from left sidebar
2. Follow setup wizard
3. Useful for tracking user behavior

## Security Best Practices

### 1. Secure API Keys
- Never commit Firebase config to public repositories
- Use environment variables in production
- Implement API key restrictions in Firebase Console

### 2. Implement Admin Roles
- Create custom claims for admin users
- Update security rules to check admin status
- Restrict vehicle management to admins only

### 3. Enable App Check
- Protects against unauthorized access
- Go to App Check in Firebase Console
- Register your app and enable

### 4. Set up Budget Alerts
- Go to Project Settings → Usage and billing
- Set budget alerts to avoid unexpected charges

## Troubleshooting

### Authentication Errors
- Verify Email/Password is enabled
- Check if email domain is allowed
- Clear app data and try again

### Firestore Permission Errors
- Check security rules are published
- Verify user is authenticated
- Check user ID matches document ID

### Network Errors
- Check internet connection
- Verify Firebase config is correct
- Check if Firestore is enabled

### Missing Data
- Verify collections are created
- Check field names match exactly
- Ensure timestamps are valid

## Next Steps

1. ✅ Firebase project created
2. ✅ Authentication enabled
3. ✅ Firestore configured
4. ✅ Security rules set
5. ✅ Sample data added
6. ✅ App configured

Your RideON app is now ready to use with Firebase!

## Support

For Firebase-specific issues:
- [Firebase Documentation](https://firebase.google.com/docs)
- [Firebase Support](https://firebase.google.com/support)
- [Stack Overflow - Firebase](https://stackoverflow.com/questions/tagged/firebase)

---

**Happy Building!** 🚀
