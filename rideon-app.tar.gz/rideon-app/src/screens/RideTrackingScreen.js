import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  FlatList,
  Alert,
  TextInput,
  Modal,
} from 'react-native';
import { collection, addDoc, getDocs, deleteDoc, doc, query, where } from 'firebase/firestore';
import { db } from '../config/firebase';
import { theme } from '../config/theme';

const AdminScreen = () => {
  const [vehicles, setVehicles] = useState([]);
  const [activeRides, setActiveRides] = useState([]);
  const [stats, setStats] = useState({ totalVehicles: 0, activeRides: 0, totalRevenue: 0 });
  const [modalVisible, setModalVisible] = useState(false);
  const [newVehicle, setNewVehicle] = useState({
    type: 'cycle',
    batteryLevel: 100,
    pricePerHour: 20,
    latitude: 28.6139,
    longitude: 77.2090,
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    await Promise.all([loadVehicles(), loadActiveRides(), calculateStats()]);
  };

  const loadVehicles = async () => {
    try {
      const vehiclesSnapshot = await getDocs(collection(db, 'vehicles'));
      const vehiclesData = [];
      vehiclesSnapshot.forEach((doc) => {
        vehiclesData.push({ id: doc.id, ...doc.data() });
      });
      setVehicles(vehiclesData);
    } catch (error) {
      console.error('Error loading vehicles:', error);
    }
  };

  const loadActiveRides = async () => {
    try {
      const q = query(collection(db, 'rides'), where('status', '==', 'active'));
      const ridesSnapshot = await getDocs(q);
      const ridesData = [];
      ridesSnapshot.forEach((doc) => {
        ridesData.push({ id: doc.id, ...doc.data() });
      });
      setActiveRides(ridesData);
    } catch (error) {
      console.error('Error loading rides:', error);
    }
  };

  const calculateStats = async () => {
    try {
      const vehiclesSnapshot = await getDocs(collection(db, 'vehicles'));
      const ridesSnapshot = await getDocs(query(collection(db, 'rides'), where('status', '==', 'active')));
      const completedRidesSnapshot = await getDocs(query(collection(db, 'rides'), where('status', '==', 'completed')));

      let totalRevenue = 0;
      completedRidesSnapshot.forEach((doc) => {
        totalRevenue += doc.data().totalCost || 0;
      });

      setStats({
        totalVehicles: vehiclesSnapshot.size,
        activeRides: ridesSnapshot.size,
        totalRevenue,
      });
    } catch (error) {
      console.error('Error calculating stats:', error);
    }
  };

  const handleAddVehicle = async () => {
    try {
      await addDoc(collection(db, 'vehicles'), {
        type: newVehicle.type,
        status: 'available',
        batteryLevel: parseInt(newVehicle.batteryLevel),
        pricePerHour: parseInt(newVehicle.pricePerHour),
        location: {
          latitude: parseFloat(newVehicle.latitude),
          longitude: parseFloat(newVehicle.longitude),
        },
        createdAt: new Date(),
      });

      Alert.alert('Success', 'Vehicle added successfully');
      setModalVisible(false);
      setNewVehicle({
        type: 'cycle',
        batteryLevel: 100,
        pricePerHour: 20,
        latitude: 28.6139,
        longitude: 77.2090,
      });
      loadData();
    } catch (error) {
      Alert.alert('Error', 'Failed to add vehicle');
    }
  };

  const handleDeleteVehicle = (vehicleId) => {
    Alert.alert(
      'Delete Vehicle',
      'Are you sure you want to delete this vehicle?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Delete',
          style: 'destructive',
          onPress: async () => {
            try {
              await deleteDoc(doc(db, 'vehicles', vehicleId));
              Alert.alert('Success', 'Vehicle deleted');
              loadData();
            } catch (error) {
              Alert.alert('Error', 'Failed to delete vehicle');
            }
          },
        },
      ]
    );
  };

  const renderVehicle = ({ item }) => (
    <View style={styles.vehicleCard}>
      <View style={styles.vehicleHeader}>
        <Text style={styles.vehicleIcon}>
          {item.type === 'cycle' ? '🚴' : '🛴'}
        </Text>
        <View style={styles.vehicleInfo}>
          <Text style={styles.vehicleType}>
            {item.type === 'cycle' ? 'Cycle' : 'E-Scooter'}
          </Text>
          <Text style={styles.vehicleId}>ID: {item.id.slice(0, 8)}</Text>
        </View>
        <View style={[
          styles.statusBadge,
          item.status === 'available' ? styles.statusAvailable : styles.statusInUse
        ]}>
          <Text style={styles.statusText}>{item.status}</Text>
        </View>
      </View>
      <View style={styles.vehicleDetails}>
        {item.type === 'escooter' && (
          <Text style={styles.detailText}>Battery: {item.batteryLevel}%</Text>
        )}
        <Text style={styles.detailText}>Price: ₹{item.pricePerHour}/hr</Text>
      </View>
      <TouchableOpacity
        style={styles.deleteButton}
        onPress={() => handleDeleteVehicle(item.id)}
      >
        <Text style={styles.deleteButtonText}>Delete</Text>
      </TouchableOpacity>
    </View>
  );

  return (
    <View style={styles.container}>
      <View style={styles.header}>
        <Text style={styles.headerTitle}>Admin Panel</Text>
      </View>

      <View style={styles.statsContainer}>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{stats.totalVehicles}</Text>
          <Text style={styles.statLabel}>Total Vehicles</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>{stats.activeRides}</Text>
          <Text style={styles.statLabel}>Active Rides</Text>
        </View>
        <View style={styles.statCard}>
          <Text style={styles.statValue}>₹{stats.totalRevenue}</Text>
          <Text style={styles.statLabel}>Revenue</Text>
        </View>
      </View>

      <View style={styles.section}>
        <View style={styles.sectionHeader}>
          <Text style={styles.sectionTitle}>Vehicles</Text>
          <TouchableOpacity
            style={styles.addButton}
            onPress={() => setModalVisible(true)}
          >
            <Text style={styles.addButtonText}>+ Add Vehicle</Text>
          </TouchableOpacity>
        </View>

        <FlatList
          data={vehicles}
          renderItem={renderVehicle}
          keyExtractor={(item) => item.id}
          contentContainerStyle={styles.listContainer}
        />
      </View>

      <Modal
        visible={modalVisible}
        animationType="slide"
        transparent={true}
        onRequestClose={() => setModalVisible(false)}
      >
        <View style={styles.modalContainer}>
          <View style={styles.modalContent}>
            <Text style={styles.modalTitle}>Add New Vehicle</Text>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Vehicle Type</Text>
              <View style={styles.typeSelector}>
                <TouchableOpacity
                  style={[
                    styles.typeButton,
                    newVehicle.type === 'cycle' && styles.typeButtonActive
                  ]}
                  onPress={() => setNewVehicle({ ...newVehicle, type: 'cycle' })}
                >
                  <Text style={styles.typeButtonText}>🚴 Cycle</Text>
                </TouchableOpacity>
                <TouchableOpacity
                  style={[
                    styles.typeButton,
                    newVehicle.type === 'escooter' && styles.typeButtonActive
                  ]}
                  onPress={() => setNewVehicle({ ...newVehicle, type: 'escooter' })}
                >
                  <Text style={styles.typeButtonText}>🛴 E-Scooter</Text>
                </TouchableOpacity>
              </View>
            </View>

            {newVehicle.type === 'escooter' && (
              <View style={styles.inputGroup}>
                <Text style={styles.label}>Battery Level (%)</Text>
                <TextInput
                  style={styles.input}
                  value={newVehicle.batteryLevel.toString()}
                  onChangeText={(text) => setNewVehicle({ ...newVehicle, batteryLevel: text })}
                  keyboardType="numeric"
                />
              </View>
            )}

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Price per Hour (₹)</Text>
              <TextInput
                style={styles.input}
                value={newVehicle.pricePerHour.toString()}
                onChangeText={(text) => setNewVehicle({ ...newVehicle, pricePerHour: text })}
                keyboardType="numeric"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Latitude</Text>
              <TextInput
                style={styles.input}
                value={newVehicle.latitude.toString()}
                onChangeText={(text) => setNewVehicle({ ...newVehicle, latitude: text })}
                keyboardType="decimal-pad"
              />
            </View>

            <View style={styles.inputGroup}>
              <Text style={styles.label}>Longitude</Text>
              <TextInput
                style={styles.input}
                value={newVehicle.longitude.toString()}
                onChangeText={(text) => setNewVehicle({ ...newVehicle, longitude: text })}
                keyboardType="decimal-pad"
              />
            </View>

            <View style={styles.modalButtons}>
              <TouchableOpacity
                style={styles.cancelButton}
                onPress={() => setModalVisible(false)}
              >
                <Text style={styles.cancelButtonText}>Cancel</Text>
              </TouchableOpacity>
              <TouchableOpacity
                style={styles.saveButton}
                onPress={handleAddVehicle}
              >
                <Text style={styles.saveButtonText}>Add Vehicle</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  header: {
    backgroundColor: theme.colors.card,
    padding: theme.spacing.lg,
    paddingTop: 50,
    ...theme.shadows.small,
  },
  headerTitle: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
  },
  statsContainer: {
    flexDirection: 'row',
    padding: theme.spacing.md,
    gap: theme.spacing.sm,
  },
  statCard: {
    flex: 1,
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    ...theme.shadows.small,
  },
  statValue: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  statLabel: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
    textAlign: 'center',
  },
  section: {
    flex: 1,
    padding: theme.spacing.md,
  },
  sectionHeader: {
    flexDirection: 'row',
    justifyContent: 'space-between',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  sectionTitle: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
  },
  addButton: {
    backgroundColor: theme.colors.primary,
    paddingHorizontal: theme.spacing.md,
    paddingVertical: theme.spacing.sm,
    borderRadius: theme.borderRadius.sm,
  },
  addButtonText: {
    color: '#ffffff',
    fontSize: theme.fontSize.sm,
    fontWeight: theme.fontWeight.semibold,
  },
  listContainer: {
    paddingBottom: theme.spacing.xl,
  },
  vehicleCard: {
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.md,
    marginBottom: theme.spacing.md,
    ...theme.shadows.small,
  },
  vehicleHeader: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.sm,
  },
  vehicleIcon: {
    fontSize: 32,
    marginRight: theme.spacing.sm,
  },
  vehicleInfo: {
    flex: 1,
  },
  vehicleType: {
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.semibold,
    color: theme.colors.text,
  },
  vehicleId: {
    fontSize: theme.fontSize.xs,
    color: theme.colors.textSecondary,
  },
  statusBadge: {
    paddingHorizontal: theme.spacing.sm,
    paddingVertical: 4,
    borderRadius: theme.borderRadius.sm,
  },
  statusAvailable: {
    backgroundColor: '#d1fae5',
  },
  statusInUse: {
    backgroundColor: '#fee2e2',
  },
  statusText: {
    fontSize: theme.fontSize.xs,
    fontWeight: theme.fontWeight.medium,
    textTransform: 'capitalize',
  },
  vehicleDetails: {
    marginBottom: theme.spacing.sm,
  },
  detailText: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: 2,
  },
  deleteButton: {
    backgroundColor: theme.colors.error,
    padding: theme.spacing.sm,
    borderRadius: theme.borderRadius.sm,
    alignItems: 'center',
  },
  deleteButtonText: {
    color: '#ffffff',
    fontSize: theme.fontSize.sm,
    fontWeight: theme.fontWeight.semibold,
  },
  modalContainer: {
    flex: 1,
    backgroundColor: 'rgba(0,0,0,0.5)',
    justifyContent: 'center',
    padding: theme.spacing.lg,
  },
  modalContent: {
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
  },
  modalTitle: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
    marginBottom: theme.spacing.lg,
  },
  inputGroup: {
    marginBottom: theme.spacing.md,
  },
  label: {
    fontSize: theme.fontSize.sm,
    fontWeight: theme.fontWeight.medium,
    color: theme.colors.text,
    marginBottom: theme.spacing.xs,
  },
  input: {
    borderWidth: 1,
    borderColor: theme.colors.border,
    borderRadius: theme.borderRadius.sm,
    padding: theme.spacing.md,
    fontSize: theme.fontSize.md,
  },
  typeSelector: {
    flexDirection: 'row',
    gap: theme.spacing.sm,
  },
  typeButton: {
    flex: 1,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.sm,
    borderWidth: 2,
    borderColor: theme.colors.border,
    alignItems: 'center',
  },
  typeButtonActive: {
    borderColor: theme.colors.primary,
    backgroundColor: '#dbeafe',
  },
  typeButtonText: {
    fontSize: theme.fontSize.md,
  },
  modalButtons: {
    flexDirection: 'row',
    gap: theme.spacing.md,
    marginTop: theme.spacing.md,
  },
  cancelButton: {
    flex: 1,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.sm,
    borderWidth: 1,
    borderColor: theme.colors.border,
    alignItems: 'center',
  },
  cancelButtonText: {
    fontSize: theme.fontSize.md,
    color: theme.colors.textSecondary,
  },
  saveButton: {
    flex: 1,
    padding: theme.spacing.md,
    borderRadius: theme.borderRadius.sm,
    backgroundColor: theme.colors.primary,
    alignItems: 'center',
  },
  saveButtonText: {
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.semibold,
    color: '#ffffff',
  },
});

export default AdminScreen;
