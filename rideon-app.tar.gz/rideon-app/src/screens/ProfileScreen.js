import React, { useState, useEffect } from 'react';
import {
  View,
  Text,
  StyleSheet,
  TouchableOpacity,
  Alert,
} from 'react-native';
import MapView, { Marker } from 'react-native-maps';
import * as Location from 'expo-location';
import { useRoute } from '@react-navigation/native';
import { doc, getDoc } from 'firebase/firestore';
import { db, auth } from '../config/firebase';
import { endRide, updateVehicleStatus, updateUser } from '../utils/firebaseUtils';
import { theme } from '../config/theme';

const RideTrackingScreen = ({ navigation }) => {
  const [location, setLocation] = useState(null);
  const [duration, setDuration] = useState(0);
  const [cost, setCost] = useState(0);
  const [rideData, setRideData] = useState(null);
  const [vehicleData, setVehicleData] = useState(null);
  const route = useRoute();
  const rideId = route.params?.rideId;

  const PRICE_PER_MINUTE = 2;

  useEffect(() => {
    loadRideData();
    startLocationTracking();

    const timer = setInterval(() => {
      setDuration((prev) => {
        const newDuration = prev + 1;
        setCost((newDuration * PRICE_PER_MINUTE) / 60);
        return newDuration;
      });
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const loadRideData = async () => {
    try {
      const rideDoc = await getDoc(doc(db, 'rides', rideId));
      if (rideDoc.exists()) {
        const ride = rideDoc.data();
        setRideData(ride);

        const vehicleDoc = await getDoc(doc(db, 'vehicles', ride.vehicleId));
        if (vehicleDoc.exists()) {
          setVehicleData(vehicleDoc.data());
        }
      }
    } catch (error) {
      console.error('Error loading ride data:', error);
    }
  };

  const startLocationTracking = async () => {
    const currentLocation = await Location.getCurrentPositionAsync({});
    setLocation({
      latitude: currentLocation.coords.latitude,
      longitude: currentLocation.coords.longitude,
      latitudeDelta: 0.005,
      longitudeDelta: 0.005,
    });

    Location.watchPositionAsync(
      {
        accuracy: Location.Accuracy.High,
        timeInterval: 5000,
        distanceInterval: 10,
      },
      (newLocation) => {
        setLocation({
          latitude: newLocation.coords.latitude,
          longitude: newLocation.coords.longitude,
          latitudeDelta: 0.005,
          longitudeDelta: 0.005,
        });
      }
    );
  };

  const handleEndRide = () => {
    Alert.alert(
      'End Ride',
      `Are you sure you want to end this ride?\n\nDuration: ${formatDuration(duration)}\nCost: ₹${cost.toFixed(2)}`,
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'End Ride',
          style: 'destructive',
          onPress: confirmEndRide,
        },
      ]
    );
  };

  const confirmEndRide = async () => {
    try {
      const finalCost = Math.ceil(cost);

      await endRide(rideId, finalCost);
      await updateVehicleStatus(rideData.vehicleId, 'available');
      await updateUser(auth.currentUser.uid, { activeRide: false });

      navigation.navigate('PaymentSummary', {
        duration,
        cost: finalCost,
        vehicleType: vehicleData?.type,
      });
    } catch (error) {
      Alert.alert('Error', 'Failed to end ride. Please try again.');
    }
  };

  const handleSOS = () => {
    Alert.alert(
      'Emergency SOS',
      'Do you need emergency assistance?',
      [
        { text: 'Cancel', style: 'cancel' },
        {
          text: 'Call Support',
          onPress: () => Alert.alert('Calling', 'Emergency support: 1800-XXX-XXXX'),
        },
      ]
    );
  };

  const formatDuration = (seconds) => {
    const hours = Math.floor(seconds / 3600);
    const minutes = Math.floor((seconds % 3600) / 60);
    const secs = seconds % 60;
    return `${hours.toString().padStart(2, '0')}:${minutes.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  if (!location || !rideData || !vehicleData) {
    return (
      <View style={styles.loadingContainer}>
        <Text>Loading ride data...</Text>
      </View>
    );
  }

  return (
    <View style={styles.container}>
      <MapView
        style={styles.map}
        region={location}
        showsUserLocation
      >
        <Marker coordinate={location} title="You are here" />
      </MapView>

      <View style={styles.statsContainer}>
        <View style={styles.statsCard}>
          <Text style={styles.statsLabel}>Duration</Text>
          <Text style={styles.statsValue}>{formatDuration(duration)}</Text>
        </View>
        <View style={styles.statsCard}>
          <Text style={styles.statsLabel}>Estimated Cost</Text>
          <Text style={styles.statsValue}>₹{cost.toFixed(2)}</Text>
        </View>
      </View>

      <View style={styles.infoCard}>
        <View style={styles.vehicleInfo}>
          <Text style={styles.vehicleIcon}>
            {vehicleData.type === 'cycle' ? '🚴' : '🛴'}
          </Text>
          <View style={styles.vehicleDetails}>
            <Text style={styles.vehicleType}>
              {vehicleData.type === 'cycle' ? 'Cycle' : 'E-Scooter'}
            </Text>
            <Text style={styles.vehicleId}>ID: {rideData.vehicleId.slice(0, 8)}</Text>
          </View>
        </View>

        <View style={styles.actionButtons}>
          <TouchableOpacity
            style={styles.sosButton}
            onPress={handleSOS}
          >
            <Text style={styles.sosButtonText}>🚨 SOS</Text>
          </TouchableOpacity>

          <TouchableOpacity
            style={styles.endRideButton}
            onPress={handleEndRide}
          >
            <Text style={styles.endRideButtonText}>End Ride</Text>
          </TouchableOpacity>
        </View>
      </View>

      <View style={styles.priceInfo}>
        <Text style={styles.priceInfoText}>
          ₹{(PRICE_PER_MINUTE * 60).toFixed(0)}/hour
        </Text>
      </View>
    </View>
  );
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: theme.colors.background,
  },
  loadingContainer: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  map: {
    flex: 1,
  },
  statsContainer: {
    position: 'absolute',
    top: 50,
    left: theme.spacing.md,
    right: theme.spacing.md,
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  statsCard: {
    flex: 1,
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.md,
    alignItems: 'center',
    ...theme.shadows.medium,
  },
  statsLabel: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginBottom: theme.spacing.xs,
  },
  statsValue: {
    fontSize: theme.fontSize.xl,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.primary,
  },
  infoCard: {
    position: 'absolute',
    bottom: 20,
    left: theme.spacing.md,
    right: theme.spacing.md,
    backgroundColor: theme.colors.card,
    borderRadius: theme.borderRadius.lg,
    padding: theme.spacing.lg,
    ...theme.shadows.medium,
  },
  vehicleInfo: {
    flexDirection: 'row',
    alignItems: 'center',
    marginBottom: theme.spacing.md,
  },
  vehicleIcon: {
    fontSize: 40,
    marginRight: theme.spacing.md,
  },
  vehicleDetails: {
    flex: 1,
  },
  vehicleType: {
    fontSize: theme.fontSize.lg,
    fontWeight: theme.fontWeight.bold,
    color: theme.colors.text,
  },
  vehicleId: {
    fontSize: theme.fontSize.sm,
    color: theme.colors.textSecondary,
    marginTop: theme.spacing.xs,
  },
  actionButtons: {
    flexDirection: 'row',
    gap: theme.spacing.md,
  },
  sosButton: {
    flex: 1,
    backgroundColor: theme.colors.error,
    borderRadius: theme.borderRadius.sm,
    padding: theme.spacing.md,
    alignItems: 'center',
  },
  sosButtonText: {
    color: '#ffffff',
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.semibold,
  },
  endRideButton: {
    flex: 2,
    backgroundColor: theme.colors.primary,
    borderRadius: theme.borderRadius.sm,
    padding: theme.spacing.md,
    alignItems: 'center',
  },
  endRideButtonText: {
    color: '#ffffff',
    fontSize: theme.fontSize.md,
    fontWeight: theme.fontWeight.semibold,
  },
  priceInfo: {
    position: 'absolute',
    top: 140,
    right: theme.spacing.md,
    backgroundColor: theme.colors.secondary,
    borderRadius: theme.borderRadius.md,
    padding: theme.spacing.sm,
  },
  priceInfoText: {
    color: '#ffffff',
    fontSize: theme.fontSize.sm,
    fontWeight: theme.fontWeight.semibold,
  },
});

export default RideTrackingScreen;
