import {
  collection,
  addDoc,
  updateDoc,
  doc,
  getDoc,
  getDocs,
  query,
  where,
  serverTimestamp
} from 'firebase/firestore';
import { db } from '../config/firebase';

// User operations
export const createUser = async (userId, userData) => {
  try {
    await setDoc(doc(db, 'users', userId), {
      ...userData,
      activeRide: false,
      subscriptionStatus: 'none',
      createdAt: serverTimestamp(),
    });
    return { success: true };
  } catch (error) {
    console.error('Error creating user:', error);
    return { success: false, error: error.message };
  }
};

export const getUser = async (userId) => {
  try {
    const userDoc = await getDoc(doc(db, 'users', userId));
    if (userDoc.exists()) {
      return { success: true, data: userDoc.data() };
    }
    return { success: false, error: 'User not found' };
  } catch (error) {
    console.error('Error getting user:', error);
    return { success: false, error: error.message };
  }
};

export const updateUser = async (userId, updates) => {
  try {
    await updateDoc(doc(db, 'users', userId), updates);
    return { success: true };
  } catch (error) {
    console.error('Error updating user:', error);
    return { success: false, error: error.message };
  }
};

// Vehicle operations
export const getAvailableVehicles = async () => {
  try {
    const q = query(collection(db, 'vehicles'), where('status', '==', 'available'));
    const querySnapshot = await getDocs(q);
    const vehicles = [];
    querySnapshot.forEach((doc) => {
      vehicles.push({ id: doc.id, ...doc.data() });
    });
    return { success: true, data: vehicles };
  } catch (error) {
    console.error('Error getting vehicles:', error);
    return { success: false, error: error.message };
  }
};

export const getVehicleById = async (vehicleId) => {
  try {
    const vehicleDoc = await getDoc(doc(db, 'vehicles', vehicleId));
    if (vehicleDoc.exists()) {
      return { success: true, data: { id: vehicleDoc.id, ...vehicleDoc.data() } };
    }
    return { success: false, error: 'Vehicle not found' };
  } catch (error) {
    console.error('Error getting vehicle:', error);
    return { success: false, error: error.message };
  }
};

export const updateVehicleStatus = async (vehicleId, status) => {
  try {
    await updateDoc(doc(db, 'vehicles', vehicleId), {
      status,
      updatedAt: serverTimestamp()
    });
    return { success: true };
  } catch (error) {
    console.error('Error updating vehicle:', error);
    return { success: false, error: error.message };
  }
};

// Ride operations
export const createRide = async (rideData) => {
  try {
    const rideRef = await addDoc(collection(db, 'rides'), {
      ...rideData,
      startTime: serverTimestamp(),
      endTime: null,
      totalCost: 0,
      status: 'active',
    });
    return { success: true, rideId: rideRef.id };
  } catch (error) {
    console.error('Error creating ride:', error);
    return { success: false, error: error.message };
  }
};

export const endRide = async (rideId, totalCost) => {
  try {
    await updateDoc(doc(db, 'rides', rideId), {
      endTime: serverTimestamp(),
      totalCost,
      status: 'completed',
    });
    return { success: true };
  } catch (error) {
    console.error('Error ending ride:', error);
    return { success: false, error: error.message };
  }
};

export const getUserRides = async (userId) => {
  try {
    const q = query(collection(db, 'rides'), where('userId', '==', userId));
    const querySnapshot = await getDocs(q);
    const rides = [];
    querySnapshot.forEach((doc) => {
      rides.push({ id: doc.id, ...doc.data() });
    });
    return { success: true, data: rides };
  } catch (error) {
    console.error('Error getting rides:', error);
    return { success: false, error: error.message };
  }
};

export const getActiveRide = async (userId) => {
  try {
    const q = query(
      collection(db, 'rides'),
      where('userId', '==', userId),
      where('status', '==', 'active')
    );
    const querySnapshot = await getDocs(q);
    if (!querySnapshot.empty) {
      const rideDoc = querySnapshot.docs[0];
      return { success: true, data: { id: rideDoc.id, ...rideDoc.data() } };
    }
    return { success: false, error: 'No active ride' };
  } catch (error) {
    console.error('Error getting active ride:', error);
    return { success: false, error: error.message };
  }
};
