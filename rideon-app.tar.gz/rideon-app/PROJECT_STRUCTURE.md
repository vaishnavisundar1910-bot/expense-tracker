# RideON Project Structure

```
rideon-app/
│
├── 📱 App.js                           # Main app entry point with navigation setup
│
├── 📦 package.json                     # Dependencies and scripts
├── ⚙️ app.json                         # Expo configuration
├── 🔧 babel.config.js                  # Babel configuration
├── 🚫 .gitignore                       # Git ignore rules
│
├── 📖 README.md                        # Main documentation
├── 📖 FIREBASE_SETUP.md                # Firebase setup guide
├── 📖 DATABASE_SCHEMA.md               # Database structure documentation
├── 📖 PROJECT_STRUCTURE.md             # This file
│
├── 📁 src/
│   │
│   ├── 📁 config/
│   │   ├── firebase.js                 # Firebase initialization and config
│   │   └── theme.js                    # App-wide theme (colors, fonts, spacing)
│   │
│   ├── 📁 utils/
│   │   └── firebaseUtils.js            # Firebase helper functions (CRUD operations)
│   │
│   └── 📁 screens/
│       ├── LoginScreen.js              # User login
│       ├── SignupScreen.js             # User registration
│       ├── HomeScreen.js               # Map view with nearby vehicles
│       ├── ScannerScreen.js            # QR code scanner
│       ├── RideTrackingScreen.js       # Active ride tracking
│       ├── PaymentSummaryScreen.js     # Payment after ride completion
│       ├── RidesHistoryScreen.js       # Past rides history
│       ├── ProfileScreen.js            # User profile management
│       └── AdminScreen.js              # Admin panel for vehicle management
│
└── 📁 assets/                          # (To be created)
    ├── icon.png                        # App icon
    ├── splash.png                      # Splash screen
    └── adaptive-icon.png               # Android adaptive icon
```

## 📱 Screens Overview

### Authentication Flow
- **LoginScreen.js** - Email/password login
- **SignupScreen.js** - New user registration with college ID

### Main App Flow
- **HomeScreen.js** - Browse and select vehicles on map
- **ScannerScreen.js** - Scan QR code to unlock vehicle
- **RideTrackingScreen.js** - Track active ride with timer and GPS
- **PaymentSummaryScreen.js** - Complete payment after ride
- **RidesHistoryScreen.js** - View past rides and billing
- **ProfileScreen.js** - User settings and account info
- **AdminScreen.js** - Admin panel for vehicle management

## 🧩 Component Breakdown

### Navigation Structure
```
App
├── AuthStack (if not logged in)
│   ├── LoginScreen
│   └── SignupScreen
│
└── AppStack (if logged in)
    ├── MainTabs (Bottom Navigation)
    │   ├── Home
    │   ├── Scan
    │   ├── Rides
    │   └── Profile
    │
    └── Modal Screens
        ├── RideTracking
        ├── PaymentSummary
        └── Admin
```

## 🎨 Design System

### Color Palette (theme.js)
- **Primary**: #2563eb (Blue)
- **Secondary**: #10b981 (Green)
- **Background**: #f8fafc
- **Card**: #ffffff
- **Text**: #1e293b
- **Text Secondary**: #64748b
- **Error**: #ef4444
- **Success**: #10b981

### Typography
- **XS**: 12px
- **SM**: 14px
- **MD**: 16px
- **LG**: 18px
- **XL**: 24px
- **XXL**: 32px

### Spacing
- **XS**: 4px
- **SM**: 8px
- **MD**: 16px
- **LG**: 24px
- **XL**: 32px

## 🔥 Firebase Structure

### Collections
1. **users** - User profiles
2. **vehicles** - Available cycles and e-scooters
3. **rides** - Active and completed rides

See `DATABASE_SCHEMA.md` for detailed structure.

## 📦 Key Dependencies

```json
{
  "expo": "~51.0.0",
  "react": "18.2.0",
  "react-native": "0.74.0",
  "react-native-maps": "1.14.0",
  "expo-location": "~17.0.1",
  "expo-barcode-scanner": "~13.0.1",
  "@react-navigation/native": "^6.1.9",
  "@react-navigation/bottom-tabs": "^6.5.11",
  "@react-navigation/stack": "^6.3.20",
  "firebase": "^10.7.1"
}
```

## 🚀 Scripts

```bash
npm start       # Start Expo dev server
npm run android # Run on Android
npm run ios     # Run on iOS
npm run web     # Run on web
```

## 🎯 Features per Screen

### HomeScreen
- Interactive map with vehicle markers
- Filter by vehicle type (Cycle/E-Scooter)
- Show battery level and pricing
- Real-time location updates

### ScannerScreen
- Camera-based QR scanner
- Visual scanning frame
- Vehicle verification
- Auto-unlock on successful scan

### RideTrackingScreen
- Live timer with HH:MM:SS format
- Real-time cost calculation
- GPS tracking
- Emergency SOS button
- End ride functionality

### PaymentSummaryScreen
- Ride summary with duration and cost
- Multiple payment options (UPI, Card, Wallet)
- Payment confirmation flow

### RidesHistoryScreen
- Chronological ride list
- Filter by status (Active/Completed)
- Total rides count
- Cost breakdown per ride

### ProfileScreen
- User information display
- Subscription status
- Wallet balance
- Settings and support
- Logout functionality

### AdminScreen
- Add/remove vehicles
- Monitor active rides
- View total revenue
- Vehicle status management
- Real-time statistics

## 🔐 Security Features

- Firebase Authentication
- Firestore Security Rules
- User data isolation
- Admin role checking
- Secure payment flow

## 📊 State Management

- React Hooks (useState, useEffect)
- Firebase real-time listeners
- Navigation state
- User authentication state

## 🎨 UI Components

- Custom styled buttons
- Card components
- Modal dialogs
- Tab navigation
- Map markers
- QR scanner overlay
- Stats cards
- Form inputs

## 🧪 Testing Checklist

- [ ] User can sign up
- [ ] User can log in
- [ ] Map shows vehicles
- [ ] QR scanner works
- [ ] Ride can be started
- [ ] Timer runs correctly
- [ ] Cost calculates properly
- [ ] Ride can be ended
- [ ] Payment flow works
- [ ] History shows rides
- [ ] Profile displays data
- [ ] Admin can add vehicles
- [ ] Admin can delete vehicles

## 📱 Platform Support

- ✅ iOS (via Expo)
- ✅ Android (via Expo)
- ✅ Web (limited features)

## 🔮 Future Enhancements

- Push notifications
- Real-time chat support
- Referral system
- Subscription plans
- Analytics dashboard
- IoT vehicle integration
- Multi-language support
- Dark mode

---

**Built with ❤️ for RideON**
