# 🚀 Quick Start Guide - RideON

Get your RideON app up and running in 10 minutes!

## Prerequisites

Before you begin, make sure you have:
- ✅ Node.js (v14 or higher) installed
- ✅ npm or yarn package manager
- ✅ A Google/Gmail account (for Firebase)
- ✅ Expo Go app on your phone (for testing)

## Step 1: Install Dependencies (2 minutes)

```bash
cd rideon-app
npm install
```

## Step 2: Set Up Firebase (5 minutes)

### 2.1 Create Firebase Project
1. Go to [Firebase Console](https://console.firebase.google.com/)
2. Click "Add project" → Enter "RideON" → Create

### 2.2 Get Firebase Config
1. Click the web icon (`</>`)
2. Register app as "RideON Mobile"
3. Copy the `firebaseConfig` object

### 2.3 Update Config File
Open `src/config/firebase.js` and replace with your config:

```javascript
const firebaseConfig = {
  apiKey: "YOUR_API_KEY",
  authDomain: "YOUR_PROJECT.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT.appspot.com",
  messagingSenderId: "YOUR_SENDER_ID",
  appId: "YOUR_APP_ID"
};
```

### 2.4 Enable Authentication
1. In Firebase Console → Authentication → Get Started
2. Enable "Email/Password" sign-in method

### 2.5 Create Firestore Database
1. Firestore Database → Create Database
2. Start in **production mode**
3. Choose nearest location → Enable

### 2.6 Add Security Rules
Click "Rules" tab and paste:

```javascript
rules_version = '2';
service cloud.firestore {
  match /databases/{database}/documents {
    match /users/{userId} {
      allow read, write: if request.auth != null && request.auth.uid == userId;
    }
    match /vehicles/{vehicleId} {
      allow read: if request.auth != null;
      allow write: if request.auth != null;
    }
    match /rides/{rideId} {
      allow read, create: if request.auth != null;
      allow update: if request.auth != null && resource.data.userId == request.auth.uid;
    }
  }
}
```

Click "Publish"

## Step 3: Add Sample Data (2 minutes)

### Add a Sample Vehicle
1. Go to Firestore Database
2. Click "Start collection" → Collection ID: `vehicles`
3. Add document with Auto-ID
4. Add these fields:

```
type: "cycle"
status: "available"
location: (map)
  - latitude: 28.6139
  - longitude: 77.2090
pricePerHour: 20
createdAt: (timestamp) [current time]
```

5. Click "Save"

**Add another for E-Scooter:**
```
type: "escooter"
status: "available"
location: (map)
  - latitude: 28.6129
  - longitude: 77.2095
batteryLevel: 85
pricePerHour: 30
createdAt: (timestamp) [current time]
```

## Step 4: Run the App (1 minute)

```bash
npm start
```

This will:
- Start the Expo development server
- Show a QR code in the terminal
- Open Metro bundler in browser

## Step 5: Test on Your Phone

### On iOS:
1. Open Camera app
2. Scan the QR code
3. Tap the notification to open in Expo Go

### On Android:
1. Open Expo Go app
2. Tap "Scan QR Code"
3. Scan the QR code from terminal

## 🎉 You're Ready!

Your app should now be running! Try:

1. **Sign Up** with a test email (e.g., `test@example.com`)
2. **View Map** - You should see 2 vehicles
3. **Tap a vehicle** to see details
4. **Scan QR** (you can test with any QR code for now)

## 🐛 Troubleshooting

### "Firebase not initialized"
→ Make sure you updated `src/config/firebase.js` with your config

### "No vehicles showing"
→ Check you added sample vehicles in Firestore

### "Location permission denied"
→ Allow location access when prompted

### "Camera not working"
→ Allow camera access when prompted (works better on real device)

## 📚 Next Steps

Now that your app is running:

1. ✅ Read `README.md` for full documentation
2. ✅ Check `DATABASE_SCHEMA.md` for database structure
3. ✅ See `FIREBASE_SETUP.md` for advanced Firebase setup
4. ✅ Explore `PROJECT_STRUCTURE.md` to understand the code

## 🔧 Development Tips

### Hot Reload
- Shake your phone to open developer menu
- Enable "Fast Refresh" for instant updates

### Debugging
- Press `j` in terminal to open Chrome DevTools
- Use `console.log()` for debugging
- Check Expo DevTools in browser

### Testing Different Screens
- You can navigate directly by modifying initial route in `App.js`

## 🎨 Customization

Want to customize? Here's where to look:

- **Colors**: `src/config/theme.js`
- **Pricing**: `src/screens/RideTrackingScreen.js` (line 23)
- **Default Location**: `src/screens/HomeScreen.js`
- **Firebase Config**: `src/config/firebase.js`

## 📱 Run on Specific Platform

```bash
npm run android  # Android only
npm run ios      # iOS only
npm run web      # Web browser
```

## 🚀 Ready to Build?

When you're ready to deploy:

```bash
# Install EAS CLI
npm install -g eas-cli

# Configure EAS
eas build:configure

# Build for Android
eas build --platform android

# Build for iOS
eas build --platform ios
```

## 💡 Pro Tips

1. **Use Expo Go** for development (fastest)
2. **Test on real device** for best experience
3. **Clear Expo cache** if you see weird errors: `expo start -c`
4. **Check Firebase Console** to see data in real-time

## 🆘 Need Help?

- 📖 Read the full [README.md](README.md)
- 🔥 Check [Firebase Setup Guide](FIREBASE_SETUP.md)
- 💬 Open an issue on GitHub
- 📧 Contact: support@rideon.com

---

**Happy Coding! 🎉**

Start building the future of micro-mobility with RideON!
